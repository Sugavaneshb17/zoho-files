package vehicle;

import java.util.Scanner;

public class bike extends TwoWheeler {
    
    public String mode = "gear";
    public  String VehicleType = "bike";

    public void setMileage() {

        if (fueltype.equals("petrol")) {
            mileage = 50;
        }
        else if (fueltype.equals("ev")) {
            mileage = 120;
        }
    }

    public bike(Scanner sc) {

        sc.nextLine();

        System.out.print("Enter the Brand name: ");
        brandname = sc.nextLine();

        System.out.print("Enter the Color: ");
        color = sc.nextLine();

        System.out.print("Enter the Fueltype: ");
        fueltype = sc.nextLine();

        System.out.print("Enter the Price: ");
        price = sc.nextDouble();

        setMileage();

        sc.nextLine();
    }

    public void printBike() {

        System.out.println("Brand Name = " + brandname);
        System.out.println("price = " + price);
        System.out.println("Fuel Type = " + fueltype);
        System.out.println("Mode = " + mode);
        System.out.println("Color = " + color);
        System.out.println("Seat = " + seat);
        System.out.println("Wheels = " + wheelcount);
        System.out.println("Mileage = " + mileage);

    }
}
