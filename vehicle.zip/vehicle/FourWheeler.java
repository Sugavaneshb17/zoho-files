package vehicle;

public class FourWheeler extends Vehicle {
    
    public int wheelcount = 4;
    
    public void printFourWheeler() {
        
        System.out.println("Brand Name = " + brandname);
        System.out.println("price = " + price);
        System.out.println("Fuel Type = " + fueltype);
        System.out.println("Mode = " + mode);

    }
}

