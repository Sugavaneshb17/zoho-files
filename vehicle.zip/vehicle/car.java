package vehicle;

import java.util.Scanner;

public class car extends FourWheeler {
    
    public  String VehicleType = "car";
    public boolean infotainment;

    public void setMileage() {

        if (fueltype.equals("petrol")) {
            mileage = 25;
        }
        else if (fueltype.equals("ev")) {
            mileage = 80;
        }
    }

    public car(Scanner sc) {

        sc.nextLine();

        System.out.print("Enter the Brand name: ");
        brandname = sc.nextLine();

        System.out.print("Enter the Color: ");
        color = sc.nextLine();

        System.out.print("Enter the Fueltype: ");
        fueltype = sc.nextLine();

        System.out.print("Enter the Price: ");
        price = sc.nextDouble();

        System.out.println("Enter the mode");
        mode = sc.nextLine();

        System.out.println("Infotainment (true/false)?");
        infotainment = sc.nextBoolean();

        setMileage();

        sc.nextLine();
    }

    public void printCar() {

        System.out.println("Brand Name = " + brandname);
        System.out.println("price = " + price);
        System.out.println("Fuel Type = " + fueltype);
        System.out.println("Mode = " + mode);
        System.out.println("Color = " + color);
        System.out.println("Seat = " + seat);
        System.out.println("Wheels = " + wheelcount);
        System.out.println("Mileage = " + mileage);
        System.out.println("Infotainment = " + infotainment);

    }
}
