package vehicle;

public class TwoWheeler extends Vehicle {
    
    public int seat = 2;
    public int wheelcount = 2;
    

    public void printTwoWheeler() {
        
        System.out.println("Brand Name = " + brandname);
        System.out.println("price = " + price);
        System.out.println("Fuel Type = " + fueltype);
        System.out.println("Mode = " + mode);

    }
}

