package vehicle;

public class Vehicle {
    
    public String brandname;
    public String color;
    public int seat;
    public int wheelcount;
    public String fueltype;
    public double mileage;
    public double price;
    public String mode;
    public String VehicleType;

    public void printVehicles() {
        
        System.out.println("Brand Name = " + brandname);
        System.out.println("price = " + price);
        System.out.println("Fuel Type = " + fueltype);
        System.out.println("Mode = " + mode);
        
    }
}
