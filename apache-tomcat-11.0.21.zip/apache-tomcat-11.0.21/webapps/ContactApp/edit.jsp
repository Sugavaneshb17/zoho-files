<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Contact</title>
</head>
<body>
    <h2>Edit Contact</h2>
    <%
        // 1. Get the ID from the URL parameter
        String id = request.getParameter("id");
        
        // Variables to hold existing data
        String name = "";
        String phone = "";
        String email = "";

        // 2. Fetch current data so the user can see what they are editing
        try {
            Class.forName("org.postgresql.Driver");
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/contact", "postgres", "root");
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM contacts WHERE id = ?");
            ps.setInt(1, Integer.parseInt(id));
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                name = rs.getString("name");
                phone = rs.getString("phone");
                email = rs.getString("email");
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    %>

    <form action="contact" method="post">
        <input type="hidden" name="action" value="update">
        
        <input type="hidden" name="id" value="<%= id %>">

        Name: <input type="text" name="name" value="<%= name %>"><br><br>
        Phone: <input type="text" name="phone" value="<%= phone %>"><br><br>
        Email: <input type="email" name="email" value="<%= email %>"><br><br>
        
        <input type="submit" value="Save Changes">
    </form>
    <br>
    <a href="view.jsp">Back to List</a>
</body>
</html>