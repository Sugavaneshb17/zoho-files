<!DOCTYPE html>
<html>
<head>
<title>Add Contact</title>
</head>
<body>
<h2>Add Contact</h2>
<form action="contact" method="post">
<input type="hidden" name="action" value="add">
 Name: <input type="text" name="name"><br><br>
 Phone: <input type="text" name="phone"><br><br>
 Email: <input type="email" name="email"><br><br>
<input type="submit" value="Add">
</form>
<br>
<a href="view.jsp">View Contacts</a>
</body>
</html>