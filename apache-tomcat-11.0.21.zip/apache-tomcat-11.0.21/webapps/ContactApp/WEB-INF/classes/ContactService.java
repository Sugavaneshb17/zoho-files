
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContactService {
    private final String url = "jdbc:postgresql://localhost:5432/contact";
    private final String user = "postgres";
    private final String password = "root";

    private Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        return DriverManager.getConnection(url, user, password);
    }

    public void addContact(Contact c) throws Exception {
        String sql = "INSERT INTO contacts(name, phone, email) VALUES (?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getPhone());
            ps.setString(3, c.getEmail());
            ps.executeUpdate();
        }
    }

    public void updateContact(Contact c) throws Exception {
        String sql = "UPDATE contacts SET name=?, phone=?, email=? WHERE id=?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getPhone());
            ps.setString(3, c.getEmail());
            ps.setInt(4, c.getId());
            ps.executeUpdate();
        }
    }

    public void deleteContact(int id) throws Exception {
        String sql = "DELETE FROM contacts WHERE id=?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}