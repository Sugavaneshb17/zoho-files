import java.io.*;
import jakarta.servlet.http.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import java.sql.*;

@WebServlet("/contact")
public class ContactServlet extends HttpServlet {
    private ContactService service = new ContactService();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        try {
            if ("add".equals(action)) {
                Contact c = new Contact(0, request.getParameter("name"),
                        request.getParameter("phone"),
                        request.getParameter("email"));
                service.addContact(c);
            } else if ("update".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                Contact c = new Contact(id, request.getParameter("name"),
                        request.getParameter("phone"),
                        request.getParameter("email"));
                service.updateContact(c);
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                service.deleteContact(id);
            }
            response.sendRedirect("view.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(500, e.getMessage());
        }
    }
}