import java.io.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

public class CalculatorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            double n1 = Double.parseDouble(request.getParameter("num1"));
            double n2 = Double.parseDouble(request.getParameter("num2"));
            String op = request.getParameter("operator");
            double result = 0;

            switch (op) {
                case "add":
                    result = n1 + n2;
                    break;
                case "subtract":
                    result = n1 - n2;
                    break;
                case "multiply":
                    result = n1 * n2;
                    break;
                case "divide":
                    if (n2 != 0)
                        result = n1 / n2;
                    else {
                        out.println("<h3>Error: Cannot divide by zero</h3>");
                        return;
                    }
                    break;
            }

            out.println("<html><body>");
            out.println("<h3>Result: " + result + "</h3>");
            out.println("<a href='index.html'>Back</a>");
            out.println("</body></html>");

        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }
}