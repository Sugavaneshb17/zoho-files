import java.io.*;
import jakarta.servlet.http.*;

public class HelloServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException {

        String name = request.getParameter("username");
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();
        out.println("<h1>Hello " + name + " </h1>");
    }
}
