javac -cp "lib/servlet-api.jar" ~/Downloads/apache-tomcat-11.0.21/webapps/myapps/WEB-INF/classes/HelloServlet.java


javac -cp "lib/servlet-api.jar" ~/Downloads/apache-tomcat-11.0.21/webapps/myapps/WEB-INF/classes/CalculatorServlet.java

javac -cp "lib/servlet-api.jar" ~/Downloads/apache-tomcat-11.0.21/webapps/ContactApp/WEB-INF/classes/ContactServlet.java
